#ifndef MATHSLIB_ADDER_H
#define MATHSLIB_ADDER_H

int add(int a, int b);

#endif
